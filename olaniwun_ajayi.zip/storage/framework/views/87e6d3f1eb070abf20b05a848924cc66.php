<?php $__env->startSection('auth_body'); ?>
    <?php echo e($slot); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::auth.auth-page', ['authType' => 'login'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\olaniwun\resources\views/layouts/guest.blade.php ENDPATH**/ ?>