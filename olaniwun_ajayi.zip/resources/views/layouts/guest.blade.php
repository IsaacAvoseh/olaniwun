@extends('adminlte::auth.auth-page', ['authType' => 'login'])

@section('auth_body')
    {{ $slot }}
@stop
